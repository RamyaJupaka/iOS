//
//  ViewController.swift
//  timer
//
//  Created by english on 2019-11-01.
//  Copyright © 2019 english. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var img: UIImageView!
    
    var timer = Timer()
    var time  = 210
    
    
    @objc func decreaseTime()
    {
        if time > 0
        {
            time -= 1
            label.text = String(time)
        }
        else
        {
            timer.invalidate()
        }
    }
    
    @IBOutlet weak var label: UILabel!
    
    @IBAction func play(_ sender: Any)
    {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(decreaseTime), userInfo: nil, repeats: true)
    }
    
    @IBAction func pause(_ sender: UIBarButtonItem)
    {
        timer .invalidate()
        label.text = String(time)
    }
    
    @IBAction func increase(_ sender: Any)
    {
        time =  time + 10
        label.text = String(time)
        img.image = UIImage(named: "up")
    }
    @IBAction func reset(_ sender: Any)
    {
        time = 210
        label.text = String(time)
        //label.text = "210"
        img.image = nil
    }
    
    @IBAction func decrease(_ sender: Any)
    {
        if time <= 0
        {
            timer.invalidate()
        }
        else{
        time =  time - 10
        label.text = String(time)
        img.image = UIImage(named: "down")
            
        }

    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }


}

